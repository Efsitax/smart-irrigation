package com.kadir.smartirrigation.schedule.dto;

import lombok.Data;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Set;

@Data
public class CreateScheduleDto {
    private LocalTime time;
    private Set<DayOfWeek> days;
    private int durationInSeconds;
    private boolean repeatDaily;
    private LocalDate specificDate;
}
